import pygame
import random

# set up game window
pygame.init()
screen_width = 288
screen_height = 512
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Flappy Bird")

# load game assets
bg_image = pygame.image.load("background.png").convert()
bird_image = pygame.image.load("bird.png").convert()
pipe_image = pygame.image.load("pipe.jpeg").convert()
pipe_list = []

# define game variables
gravity = 0.25
bird_movement = 0
game_active = True
score = 0
font = pygame.font.Font(None, 36)

# define helper functions
def create_pipe():
    random_pipe_pos = random.choice(pipe_height)
    bottom_pipe = pipe_image.get_rect(midtop = (screen_width+100, random_pipe_pos))
    top_pipe = pipe_image.get_rect(midbottom = (screen_width+100, random_pipe_pos-150))
    return bottom_pipe, top_pipe

def move_pipes(pipes):
    for pipe in pipes:
        pipe.centerx -= 2.5
    return pipes

def draw_pipes(pipes):
    for pipe in pipes:
        if pipe.bottom >= screen_height:
            screen.blit(pipe_image, pipe)
        else:
            flip_pipe = pygame.transform.flip(pipe_image, False, True)
            screen.blit(flip_pipe, pipe)

def check_collision(pipes):
    for pipe in pipes:
        if bird_rect.colliderect(pipe):
            return False
    if bird_rect.top <= -100 or bird_rect.bottom >= 400:
        return False
    return True

def score_display(game_state):
    if game_state == "main_game":
        score_surface = font.render(str(int(score)), True, (255, 255, 255))
        score_rect = score_surface.get_rect(center = (screen_width//2, 50))
        screen.blit(score_surface, score_rect)
    if game_state == "game_over":
        score_surface = font.render(f'Score: {int(score)}', True, (255, 255, 255))
        score_rect = score_surface.get_rect(center = (screen_width//2, 50))
        screen.blit(score_surface, score_rect)

        high_score_surface = font.render(f'High score: {int(high_score)}', True, (255, 255, 255))
        high_score_rect = high_score_surface.get_rect(center = (screen_width//2, 425))
        screen.blit(high_score_surface, high_score_rect)

def update_score(score, high_score):
    if score > high_score:
        high_score = score
    return high_score

# set up game loop
clock = pygame.time.Clock()
FPS = 60
pipe_height = [200, 300, 400]
bird_rect = bird_image.get_rect(center = (50, screen_height//2))


while True:
    # handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and game_active:
                bird_movement = 0
                bird_movement -= 8
            if event.key == pygame.K_SPACE and not game_active:
                game_active = True
                pipe_list.clear()
                bird_rect.center = (50, screen_height//2)
                bird_movement = 0
                score = 0

    # set up game background
    screen.blit(bg_image, (0, 0))

    # update bird
    bird_movement += gravity
    bird_rect = bird_image.get_rect(center = (50, bird_rect.centery))
